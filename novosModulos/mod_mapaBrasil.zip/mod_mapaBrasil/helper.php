<?php

class ModMapaBrasilHelper
{
    /**
     * Retrieves the hello message
     *
     * @param   array  $params An object containing the module parameters
     *
     * @access public
     */    
    public static function getHello($params)
    {
	return 'Mapa do Brasil';
    }
}
